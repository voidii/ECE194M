﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Ghost : MonoBehaviour
{
    // Start is called before the first frame update

    public float moveSpeed = 5.9f;
    public float normalMoveSpeed = 5.9f;
    public float FSpeed = 2.9f;
    public float CSpeed = 15f;

    public bool canMove = true;

    public float ghostReleaseTimer = 0;

    public int pinkyReleaseTimer = 5;
    public int inkyReleaseTimer = 14;
    public int clyedeReleaseTimer = 21;
    public int fModeDuration = 10;
    private float fModeTimer = 0;
    public int startBAt = 7;
    private float BTimer = 0;
    public bool isInGhostHouse = false;

    private bool iswhite = false;

    public Node startingPosition;
    public Node homeNode;
    public Node ghostHouse;

    public int scatterModeTimer1 = 7;
    public int chaseModeTimer1 = 20;
    public int scatterModeTimer2 = 7;
    public int chaseModeTimer2 = 20;
    public int scatterModeTimer3 = 5;
    public int chaseModeTimer3 = 20;
    public int scatterModeTimer4 = 5;
    public int chaseModeTimer4 = 20;

    public Sprite eyesUp;
    public Sprite eyesDown;
    public Sprite eyesLeft;
    public Sprite eyesRight;

    private int modeChangeIteration = 1;
    private float modeChangeTimer = 0;
    private float preSpeed;

    public RuntimeAnimatorController ghostUp;
    public RuntimeAnimatorController ghostDown;
    public RuntimeAnimatorController ghostLeft;
    public RuntimeAnimatorController ghostRight;
    public RuntimeAnimatorController wihte;
    public RuntimeAnimatorController blue;

    private AudioSource background;

    public bool returningHome = false;


    public enum Mode{
        Chase,
        Scatter,
        Frightened,
        Consumed
    }

    public enum GhostType{
        Red,Pink,Blue,Orange
    }

    public GhostType ghostType = GhostType.Red;

    Mode currentMode = Mode.Scatter;
    Mode previousMode;

    private GameObject pacMan;

    private Node currentNode, targetNode, previousNode;
    private Vector2 direction, nextDirection;

    void Start()
    {
        background = GameObject.Find("GameBorad").transform.GetComponent<AudioSource>();
        pacMan = GameObject.FindGameObjectWithTag("PacMan");
        Node node = GetNodeAtPosition(transform.localPosition);

        if(node != null)
        {
            currentNode = node;
            
        }
        if(isInGhostHouse)
        {
            direction = Vector2.up;
            targetNode = currentNode.neighbors[0];
        }
        else{
            direction = Vector2.left;
            targetNode = ChooseNextNode();
        }

        previousNode = currentNode;
        UpdateAnimator();
    }

    // Update is called once per frame
    void Update()
    {
        ModeUpdate();
        Move();
        ReleaseGhost();
        checkCollision();
        checkInHouse();
        if(!canMove){
            moveSpeed = 0;
        }
        else if(currentMode == Mode.Consumed){
            moveSpeed = CSpeed;
        }
        else{
            moveSpeed = normalMoveSpeed;
        }
    }

    public void Restart(){
        transform.position = startingPosition.transform.position;

        ghostReleaseTimer = 0;
        modeChangeIteration = 1;
        modeChangeTimer = 0;

        if(transform.name != "ghost")
        {
            isInGhostHouse = true;
        }
        currentNode = startingPosition;
        if(isInGhostHouse)
        {
            direction = Vector2.up;
            targetNode = currentNode.neighbors[0];
        }
        else{
            direction = Vector2.left;
            targetNode = ChooseNextNode();
        }
        previousNode = currentNode;
        UpdateAnimator();
    }

    void checkInHouse(){
        
        
            GameObject tile = GetTileAtPosition(transform.position);

            if(tile != null)
            {
                if(tile.transform.GetComponent<Tile>() != null)
                {
                    if(tile.transform.GetComponent<Tile>().isGhostHouse)
                    {
                        moveSpeed = normalMoveSpeed;
                        Node node = GetNodeAtPosition(transform.position);
                        if(node != null){
                            currentNode = node;

                            direction = Vector2.up;
                            targetNode = currentNode.neighbors[0];

                            previousNode = currentNode;

                            currentMode = Mode.Chase;

                            UpdateAnimator();
                        }
                    }
                }
            }
        
    }

    void checkCollision(){

        Rect gRect = new Rect(transform.position, transform.GetComponent<SpriteRenderer>().sprite.bounds.size / 4);
        Rect pacRect = new Rect(pacMan.transform.position, pacMan.transform.GetComponent<SpriteRenderer>().sprite.bounds.size / 4);
        if(gRect.Overlaps(pacRect)){
            
            if(currentMode == Mode.Frightened){
                Debug.Log(currentMode);
                Consumed();
            }
            else if(currentMode == Mode.Consumed)
            {

            }
            else{
                GameObject.Find("GameBorad").transform.GetComponent<GameBorad>().StartDeath();
                Debug.Log("collo");
            }
        }
    }

    void UpdateAnimator(){
        
        if(currentMode != Mode.Frightened && currentMode != Mode.Consumed){
        
            if(direction == Vector2.up)
            {
                transform.GetComponent<Animator>().runtimeAnimatorController = ghostUp;
            }
            else if(direction == Vector2.right)
            {
                transform.GetComponent<Animator>().runtimeAnimatorController = ghostRight;
            }
            else if(direction == Vector2.left)
            {
                transform.GetComponent<Animator>().runtimeAnimatorController = ghostLeft;
            }
            else if(direction == Vector2.down)
            {
                transform.GetComponent<Animator>().runtimeAnimatorController = ghostDown;
            }
            else{
                transform.GetComponent<Animator>().runtimeAnimatorController = ghostLeft;
            }
        }
        else if (currentMode == Mode.Frightened){
            transform.GetComponent<Animator>().runtimeAnimatorController = blue;
        }
        else if (currentMode == Mode.Consumed)
        {
            transform.GetComponent<Animator>().runtimeAnimatorController = null;
            if(direction == Vector2.up)
            {
                 transform.GetComponent<SpriteRenderer>().sprite = eyesUp;
            }
            if(direction == Vector2.down)
            {
                 transform.GetComponent<SpriteRenderer>().sprite = eyesDown;
            }
            if(direction == Vector2.left)
            {
                 transform.GetComponent<SpriteRenderer>().sprite = eyesLeft;
            }
            if(direction == Vector2.right)
            {
                 transform.GetComponent<SpriteRenderer>().sprite = eyesRight;
            }
        }
    }

    void Consumed(){
        currentMode = Mode.Consumed;
        UpdateAnimator();
        preSpeed = moveSpeed;
        moveSpeed = CSpeed;
        GameObject.Find("GameBorad").GetComponent<GameBorad>().score += 200;
        GameObject.Find("GameBorad").GetComponent<GameBorad>().startConsued(this.GetComponent<Ghost>());
    }

    void Move()
    {
        if(targetNode != currentNode && targetNode != null && !isInGhostHouse)
        {
            if(OverShotTarget())
            {
                currentNode = targetNode;
                transform.localPosition = currentNode.transform.position;
                GameObject otherPortal = GetPortal(currentNode.transform.position);
                if(otherPortal)
                {
                    transform.localPosition = otherPortal.transform.position;
                    currentNode = otherPortal.GetComponent<Node>();
                }
                targetNode = ChooseNextNode();
                previousNode = currentNode;
                currentNode = null;

                UpdateAnimator();
            }
            else
            {
                transform.localPosition += (Vector3)direction * moveSpeed * Time.deltaTime;
            }
        }
    }

    void ModeUpdate(){
        if(currentMode != Mode.Frightened){
            modeChangeTimer += Time.deltaTime;

            if(modeChangeIteration == 1)
            {
                if(currentMode == Mode.Scatter && modeChangeTimer > scatterModeTimer1)
                {
                    ChangeMode(Mode.Chase);
                    modeChangeTimer = 0;
                }

                if(currentMode == Mode.Chase && modeChangeTimer > chaseModeTimer1)
                {
                    modeChangeIteration = 2;
                    ChangeMode(Mode.Scatter);
                    modeChangeTimer = 0;
                }
            }
            if(modeChangeIteration == 2)
            {
                if(currentMode == Mode.Scatter && modeChangeTimer > scatterModeTimer2)
                {
                    ChangeMode(Mode.Chase);
                    modeChangeTimer = 0;
                }

                if(currentMode == Mode.Chase && modeChangeTimer > chaseModeTimer2)
                {
                    modeChangeIteration = 3;
                    ChangeMode(Mode.Scatter);
                    modeChangeTimer = 0;
                }
            }
            if(modeChangeIteration == 3)
            {
                if(currentMode == Mode.Scatter && modeChangeTimer > scatterModeTimer3)
                {
                    ChangeMode(Mode.Chase);
                    modeChangeTimer = 0;
                }

                if(currentMode == Mode.Chase && modeChangeTimer > chaseModeTimer3)
                {
                    modeChangeIteration = 4;
                    ChangeMode(Mode.Scatter);
                    modeChangeTimer = 0;
                }
            }
            if(modeChangeIteration == 4)
            {
                if(currentMode == Mode.Scatter && modeChangeTimer > scatterModeTimer4)
                {
                    ChangeMode(Mode.Chase);
                    modeChangeTimer = 0;
                }

                if(currentMode == Mode.Chase && modeChangeTimer > chaseModeTimer4)
                {
                    ChangeMode(Mode.Scatter);
                    modeChangeTimer = 0;
                }
            }
        }
        else if(currentMode == Mode.Frightened)
        {
            fModeTimer += Time.deltaTime;
            if(fModeTimer > fModeDuration)
            {
                background.clip = GameObject.Find("GameBorad").transform.GetComponent<GameBorad>().Normal;
                background.Play();
                
                fModeTimer = 0;
                ChangeMode(previousMode);
            }
            if(fModeTimer >= startBAt)
            {
                BTimer += Time.deltaTime;
                if(BTimer >= 0.1f)
                {
                    BTimer = 0f;
                    if(iswhite)
                    {
                        transform.GetComponent<Animator>().runtimeAnimatorController = blue;
                        iswhite = false;
                    }
                    else{
                        transform.GetComponent<Animator>().runtimeAnimatorController = wihte;
                        iswhite = true;
                    }
                }
            }
        }
    }

    void ChangeMode(Mode m)
    {
    
        if(currentMode == Mode.Frightened)
        {
            moveSpeed = preSpeed;
        }

        if(m == Mode.Frightened)
        {
            preSpeed = moveSpeed;
            moveSpeed = FSpeed;
        }

        if(currentMode != m)
        {
            previousMode = currentMode;
            currentMode = m;
        }
        

        UpdateAnimator();
    }
    
    public void StartF(){
        fModeTimer = 0;
        background.clip = GameObject.Find("GameBorad").transform.GetComponent<GameBorad>().Frighten;
        background.Play();
        ChangeMode(Mode.Frightened);
    }

    Vector2 GetRedGhostTargetTile()
    {
        Vector2 pacManPosition = pacMan.transform.position;
        Vector2 targetTile = new Vector2(Mathf.RoundToInt(pacManPosition.x), Mathf.RoundToInt(pacManPosition.y));

        return targetTile;
    }

    Vector2 GetBlueGhostTargetTile()
    {
        Vector2 pacManPosition = pacMan.transform.localPosition;
        Vector2 pacManOri = pacMan.GetComponent<PacMan>().orientation;

        int pacManPositionX = Mathf.RoundToInt(pacManPosition.x);
        int pacManPositionY = Mathf.RoundToInt(pacManPosition.y);

        Vector2 pacManTile = new Vector2(pacManPositionX, pacManPositionY);
        Vector2 targetTile = pacManTile + (2 * pacManOri);

        Vector2 temp = GameObject.Find("ghost").transform.localPosition;

        int X = Mathf.RoundToInt(temp.x);
        int Y = Mathf.RoundToInt(temp.y);

        temp = new Vector2(X, Y);
        float d = GetDistance(temp, targetTile);
        d *= 2;

        targetTile = new Vector2 (temp.x + d, temp.y + d);

        return targetTile;
    }

    Vector2 GetPinkGhostTargetTile()
    {
        Vector2 pacManPosition = pacMan.transform.localPosition;
        Vector2 pacManOri = pacMan.GetComponent<PacMan>().orientation;

        int pacManPositionX = Mathf.RoundToInt(pacManPosition.x);
        int pacManPositionY = Mathf.RoundToInt(pacManPosition.y);

        Vector2 pacManTile = new Vector2(pacManPositionX, pacManPositionY);
        Vector2 targetTile = pacManTile + (4 * pacManOri);

        return targetTile;
    }

    Vector2 GetOrangeGhostTargetTile()
    {
        Vector2 pacManPosition = pacMan.transform.localPosition;
        
        float d = GetDistance(transform.localPosition, pacManPosition);
        Vector2 targetTile = Vector2.zero;

        if(d > 8){
            targetTile = new Vector2(Mathf.RoundToInt(pacManPosition.x), Mathf.RoundToInt(pacManPosition.y));
        }
        else if(d < 8){
            targetTile = homeNode.transform.position;
        }

        return targetTile;
    }

    Vector2 GetTargetTile()
    {
        Vector2 targetTile = Vector2.zero;
        if(ghostType == GhostType.Red)
        {
            targetTile = GetRedGhostTargetTile();
        }
        else if(ghostType == GhostType.Pink)
        {
            targetTile = GetPinkGhostTargetTile();
        }
        else if(ghostType == GhostType.Blue)
        {
            targetTile = GetBlueGhostTargetTile();
        }
        else if(ghostType == GhostType.Orange)
        {
            targetTile = GetOrangeGhostTargetTile();
        }

        return targetTile;
    }

    Vector2 GetRandomTile(){
        int x = Random.Range(0, 28);
        int y = Random.Range(0, 36);

        return new Vector2(x, y);
    }

    void ReleasePink(){
        if(ghostType == GhostType.Pink && isInGhostHouse)
        {
            isInGhostHouse = false;
        }
    }

    void ReleaseBlue(){
        if(ghostType == GhostType.Blue && isInGhostHouse)
        {
            isInGhostHouse = false;
        }
    }

    void Releaseorenge(){
        if(ghostType == GhostType.Orange && isInGhostHouse)
        {
            isInGhostHouse = false;
        }
    }

    void ReleaseGhost(){
        ghostReleaseTimer += Time.deltaTime;
        if(ghostReleaseTimer > pinkyReleaseTimer)
        {
            ReleasePink();
        }
        if(ghostReleaseTimer > inkyReleaseTimer)
        {
            ReleaseBlue();
        }
        if(ghostReleaseTimer > clyedeReleaseTimer)
        {
            Releaseorenge();
        }

    }

    Node ChooseNextNode(){
        Vector2 targetTile = Vector2.zero;

        if(currentMode == Mode.Chase)
        {
            targetTile = GetTargetTile();
        }
        else if (currentMode == Mode.Scatter)
        {
            targetTile = homeNode.transform.position;
        }
        else if(currentMode == Mode.Frightened)
        {
            targetTile = GetRandomTile();
        }
        else if(currentMode == Mode.Consumed)
        {
            targetTile = ghostHouse.transform.position;
            returningHome = true;
        }

        Node moveToNode = null;

        Node[] foundNodes = new Node[4];
        Vector2[] foundNodeDirection = new Vector2[4];

        int nodeCounter = 0;

        for(int i = 0; i < currentNode.neighbors.Length;i++)
        {
            if(currentNode.validDirections[i] != direction*-1)
            {
                //if(currentMode != Mode.Consumed)
                //{
                //    Tile tile = GetTileAtPosition(currentNode.transform.position);
                //    if(tile != null){
                //        Debug.Log(tile);
                //        if(tile.transform.GetComponent<Tile>().isGhostHouseEnterence == true)
                //        {
                //            if(currentNode.validDirections[i] != Vector2.down)
                //            {
                //                foundNodes[nodeCounter] = currentNode.neighbors[i];
                //                foundNodeDirection[nodeCounter] = currentNode.validDirections[i];
                //                nodeCounter++;
                //            }
                //        }
                //        else{
                //            foundNodes[nodeCounter] = currentNode.neighbors[i];
                //            foundNodeDirection[nodeCounter] = currentNode.validDirections[i];
                //            nodeCounter++;
                //        }
                //    }
                //    else
                //    {
                //        foundNodes[nodeCounter] = currentNode.neighbors[i];
                //        foundNodeDirection[nodeCounter] = currentNode.validDirections[i];
                //        nodeCounter++;
                //    }
                //}
                //else{
                    foundNodes[nodeCounter] = currentNode.neighbors[i];
                    foundNodeDirection[nodeCounter] = currentNode.validDirections[i];
                    nodeCounter++;
                //}
            }
        }

        if(foundNodes.Length == 1)
        {
            moveToNode = foundNodes[0];
            direction = foundNodeDirection[0];
        }
        if(foundNodes.Length > 1)
        {
            float leastDistance = 100000f;
            
            for(int i = 0; i < foundNodes.Length;i++)
            {
                if(foundNodes[i] == null)
                {
                    continue;
                }
                float d = GetDistance(foundNodes[i].transform.position, targetTile);
                
                if(d < leastDistance)
                {
                    leastDistance = d;
                    moveToNode = foundNodes[i];
                    direction = foundNodeDirection[i];
                }
            }
        }

        return moveToNode;
    }

    GameObject GetTileAtPosition(Vector2 pos){

        int tileX = Mathf.RoundToInt(pos.x);
        int tileY = Mathf.RoundToInt(pos.y);

        GameObject tile = GameObject.Find("GameBorad").GetComponent<GameBorad>().board[(int)pos.x, (int)pos.y];

        if(tile != null)
            return tile;

        return null;

    }

    Node GetNodeAtPosition(Vector2 pos)
    {
        GameObject tile = GameObject.Find("GameBorad").GetComponent<GameBorad>().board[(int)pos.x, (int)pos.y];
        if(tile != null)
        {
            if(tile.GetComponent<Node>() != null)
            {
                return tile.GetComponent<Node>();
            }
        }
        return null;
    }

    GameObject GetPortal(Vector2 pos)
    {
        GameObject tile = GameObject.Find("GameBorad").GetComponent<GameBorad>().board[(int)pos.x, (int)pos.y];
        
        if(tile != null)
        {
            if(tile.GetComponent<Tile>() == null) return null;
            if(tile.GetComponent<Tile>().isPortal)
            {
                GameObject otherPortal = tile.GetComponent<Tile>().Preciver;
                return otherPortal;
            }
        }
        return null;
    }

    float LengthFromNode(Vector2 targetPosition)
    {
        Vector2 vec = targetPosition - (Vector2)previousNode.transform.position;
        return vec.sqrMagnitude;
    }
    bool OverShotTarget(){

        float nodeToTarget = LengthFromNode(targetNode.transform.position);
        float nodeToSelf = LengthFromNode(transform.localPosition);

        return nodeToSelf > nodeToTarget;
    }

    float GetDistance(Vector2 posA, Vector2 posB)
    {
        float dx = posA.x - posB.x;
        float dy = posA.y - posB.y;

        float d = Mathf.Sqrt(dx*dx + dy*dy);

        return d;
    }
}
