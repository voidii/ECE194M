﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class Menu : MonoBehaviour
{
    public bool isOnePlayer = true;

    public Text player1;
    public Text player2;
    public Text playerSe;
    
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if(Input.GetKeyUp(KeyCode.UpArrow)){

            if(!isOnePlayer)
            {
                isOnePlayer = true;
                playerSe.transform.localPosition = new Vector3 (playerSe.transform.localPosition.x, player1.transform.localPosition.y, playerSe.transform.localPosition.z);
            }

        }
        else if(Input.GetKeyUp(KeyCode.DownArrow))
        {
            if(isOnePlayer)
            {
                isOnePlayer = false;
                playerSe.transform.localPosition = new Vector3 (playerSe.transform.localPosition.x, player2.transform.localPosition.y, playerSe.transform.localPosition.z);
            }
        }
        else if(Input.GetKeyUp(KeyCode.Return) && isOnePlayer){

            SceneManager.LoadScene("Level1");
        }
        else if(Input.GetKeyUp(KeyCode.Return))
        {
            Application.Quit(); 
            Debug.Log("quit");
        }
    }
}
