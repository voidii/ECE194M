﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class GameBorad : MonoBehaviour
{
    private static int width = 28;
    private static int height = 36;

    public int totalPellets = 0;
    public int score = 0;
    public int PacLives = 3;
    public int count = 0;
    public int level = 1;

    public AudioClip Normal;
    public AudioClip Frighten;
    public AudioClip Death;

    private bool didStartDeath = false;

    public Text player;
    public Text ready;
    public Text playerscore;
    public Text lives;
    public Text levelText;
    public Text newlevel;
    public Text consumedScore;

    public GameObject[,] board = new GameObject[width, height];
    
    // Start is called before the first frame update
    void Start()
    {
        newlevel.transform.GetComponent<Text>().enabled = false;
        consumedScore.GetComponent<Text>().enabled = false;
        Object[] objects = GameObject.FindObjectsOfType(typeof(GameObject));
        StartGame();
        foreach(GameObject o in objects){
            Vector2 pos = o.transform.position;
            if(o.name != "PacMan" && o.name != "Nodes" && o.name != "NonNode" 
            && o.name != "Maze" && o.name != "Pellets" && o.tag != "Ghost" 
            && o.tag != "GoesHome" && o.name != "Canvas" && o.name != "player" 
            && o.name != "ready" && o.name != "highscore" && o.name != "highscoreText" 
            && o.name != "score" && o.name != "scoreText" && o.name != "lives"
            && o.name != "livesText" && o.name != "level" && o.name != "levelText"
            && o.name != "newLevel" && o.name != "Text")
            {
                if(o.GetComponent<Tile>() != null)
                {
                    if(o.GetComponent<Tile>().isPellet || o.GetComponent<Tile>().isSuperPellet)
                    {
                        totalPellets++;
                    }
                }
                board[(int)pos.x, (int)pos.y] = o;
            }
            else
            {
            }
        }
    }

    public void StartGame(){

        GameObject[] o = GameObject.FindGameObjectsWithTag("Ghost");
        foreach(GameObject ghost in o)
        {
            ghost.transform.GetComponent<Ghost>().canMove = false;
            ghost.transform.GetComponent<SpriteRenderer>().enabled = false;
        }
        GameObject pacMan = GameObject.Find("PacMan");
        pacMan.transform.GetComponent<PacMan>().canMove = false;
        pacMan.transform.GetComponent<SpriteRenderer>().enabled = false;
        StartCoroutine(show(2.25f));
    }

    IEnumerator show(float delay)
    {
        yield return new WaitForSeconds(delay);
        GameObject[] o = GameObject.FindGameObjectsWithTag("Ghost");
        foreach(GameObject ghost in o)
        {
            ghost.transform.GetComponent<SpriteRenderer>().enabled = true;
        }
        GameObject pacMan = GameObject.Find("PacMan");
        pacMan.transform.GetComponent<SpriteRenderer>().enabled = true;
        player.transform.GetComponent<Text>().enabled = false;

        StartCoroutine(startafter(2));
    }

    IEnumerator startafter(float delay){
        yield return new WaitForSeconds(delay);
        GameObject[] o = GameObject.FindGameObjectsWithTag("Ghost");
        foreach(GameObject ghost in o)
        {
            ghost.transform.GetComponent<Ghost>().canMove = true;
        }
        GameObject pacMan = GameObject.Find("PacMan");
        pacMan.transform.GetComponent<PacMan>().canMove = true;

        ready.transform.GetComponent<Text>().enabled = false;
        transform.GetComponent<AudioSource>().clip = Normal;
        transform.GetComponent<AudioSource>().Play();
    }

    public void StartDeath(){
        if(!didStartDeath){

            StopAllCoroutines();
            didStartDeath = true;
            GameObject[] o = GameObject.FindGameObjectsWithTag("Ghost");
            foreach(GameObject ghost in o)
            {
                ghost.transform.GetComponent<Ghost>().canMove = false;
            }
            GameObject pacMan = GameObject.Find("PacMan");
            pacMan.transform.GetComponent<PacMan>().canMove = false;

            transform.GetComponent<AudioSource>().Stop();
            StartCoroutine(ProcessDeath(2));
        }
    }

    IEnumerator ProcessDeath(float delay)
    {
        yield return new WaitForSeconds(delay);
        GameObject[] o = GameObject.FindGameObjectsWithTag("Ghost");
        foreach(GameObject ghost in o)
        {
            ghost.transform.GetComponent<SpriteRenderer>().enabled = false;
        }
        transform.GetComponent<AudioSource>().clip = Death;
        transform.GetComponent<AudioSource>().Play();
        StartCoroutine(ProcessDeathRestart(1));
    }

    IEnumerator ProcessDeathRestart(float delay)
    {
        player.transform.GetComponent<Text>().enabled = true;
        ready.transform.GetComponent<Text>().enabled = true;
        GameObject[] o = GameObject.FindGameObjectsWithTag("Ghost");
        foreach(GameObject ghost in o)
        {
            ghost.transform.GetComponent<SpriteRenderer>().enabled = true;
        }
        yield return new WaitForSeconds(delay);

        StartCoroutine(ProcessDeathRestartObecjts(1));

    }

    IEnumerator ProcessDeathRestartObecjts(float delay){
        player.transform.GetComponent<Text>().enabled = false;
        GameObject[] o = GameObject.FindGameObjectsWithTag("Ghost");
        foreach(GameObject ghost in o)
        {
            ghost.transform.GetComponent<SpriteRenderer>().enabled = true;
        }
        GameObject pacMan = GameObject.Find("PacMan");
        pacMan.transform.GetComponent<SpriteRenderer>().enabled = true;

        yield return new WaitForSeconds(delay);


        Restart();
    }

    public void Restart(){
        ready.transform.GetComponent<Text>().enabled = false;
        if(count == 231)
        {
            level += 1;
            count = 0;
        }
        else{
            PacLives -= 1;
        }
        GameObject pacMan = GameObject.Find("PacMan");
        pacMan.transform.GetComponent<PacMan>().Restart();
        pacMan.transform.GetComponent<PacMan>().canMove = true;

        GameObject[] o = GameObject.FindGameObjectsWithTag("Ghost");
        foreach(GameObject ghost in o)
        {
            ghost.transform.GetComponent<Ghost>().Restart();
            ghost.transform.GetComponent<Ghost>().canMove = true;
        }
        //transform.GetComponent<AudioSource>().Stop();
        transform.GetComponent<AudioSource>().clip = Normal;
        transform.GetComponent<AudioSource>().Play();
        didStartDeath = false;
    }

    // Update is called once per frame
    void NewLevel(){ 
        Object[] objects = GameObject.FindObjectsOfType(typeof(GameObject));
        
        foreach(GameObject o in objects){
            Vector2 pos = o.transform.position;
            if(o.name != "PacMan" && o.name != "Nodes"
            && o.name != "Maze" && o.name != "Pellets" && o.tag != "Ghost" 
            && o.tag != "GoesHome" && o.name != "Canvas" && o.name != "player" 
            && o.name != "ready" && o.name != "highscore" && o.name != "highscoreText" 
            && o.name != "score" && o.name != "scoreText" && o.name != "lives"
            && o.name != "livesText" && o.name != "level" && o.name != "levelText"
            && o.name != "newLevel")
            {
                if(o.GetComponent<Tile>() != null)
                {
                    if(o.GetComponent<Tile>().isPellet || o.GetComponent<Tile>().isSuperPellet)
                    {
                        Tile tile = o.GetComponent<Tile>();
                        o.GetComponent<SpriteRenderer>().enabled = true;
                        tile.didConsume = false;
                    }
                }
            }
        }

        StartNewLevel();
    }

    public void StartNewLevel(){

        GameObject[] o = GameObject.FindGameObjectsWithTag("Ghost");
        foreach(GameObject ghost in o)
        {
            ghost.transform.GetComponent<Ghost>().canMove = false;
        }
        GameObject pacMan = GameObject.Find("PacMan");
        pacMan.transform.GetComponent<PacMan>().canMove = false;
        transform.GetComponent<AudioSource>().Stop();
        StartCoroutine(ProcessNewLevel(2));
        
    }

    IEnumerator ProcessNewLevel(float delay)
    {
        yield return new WaitForSeconds(delay);
        GameObject[] o = GameObject.FindGameObjectsWithTag("Ghost");
        foreach(GameObject ghost in o)
        {
            ghost.transform.GetComponent<SpriteRenderer>().enabled = false;
        }
        StartCoroutine(ProcessLevelRestart(1));
    }

    IEnumerator ProcessLevelRestart(float delay)
    {
        player.transform.GetComponent<Text>().enabled = true;
        ready.transform.GetComponent<Text>().enabled = true;
        newlevel.transform.GetComponent<Text>().enabled = true;
        GameObject[] o = GameObject.FindGameObjectsWithTag("Ghost");
        foreach(GameObject ghost in o)
        {
            ghost.transform.GetComponent<SpriteRenderer>().enabled = true;
        }
        yield return new WaitForSeconds(delay);

        StartCoroutine(ProcessLevelRestartObecjts(1));

    }

    IEnumerator ProcessLevelRestartObecjts(float delay){
        player.transform.GetComponent<Text>().enabled = false;
        newlevel.transform.GetComponent<Text>().enabled = false;
        GameObject[] o = GameObject.FindGameObjectsWithTag("Ghost");
        foreach(GameObject ghost in o)
        {
            ghost.transform.GetComponent<SpriteRenderer>().enabled = true;
        }
        GameObject pacMan = GameObject.Find("PacMan");
        pacMan.transform.GetComponent<SpriteRenderer>().enabled = true;

        yield return new WaitForSeconds(delay);

        Restart();
    }

    void GameOver(){
        GameObject[] o = GameObject.FindGameObjectsWithTag("Ghost");
        foreach(GameObject ghost in o)
        {
            ghost.transform.GetComponent<Ghost>().canMove = false;
        }
        GameObject pacMan = GameObject.Find("PacMan");
        pacMan.transform.GetComponent<PacMan>().canMove = false;
        transform.GetComponent<AudioSource>().Stop();
        StartCoroutine(ProcessNewGame(2));
        //SceneManager.LoadScene("Level1");
    }

    IEnumerator ProcessNewGame(float delay)
    {
        yield return new WaitForSeconds(delay);
        GameObject[] o = GameObject.FindGameObjectsWithTag("Ghost");
        foreach(GameObject ghost in o)
        {
            ghost.transform.GetComponent<SpriteRenderer>().enabled = false;
        }
        StartCoroutine(ProcessGameRestart(1));
    }

    IEnumerator ProcessGameRestart(float delay)
    {
        yield return new WaitForSeconds(delay);
        SceneManager.LoadScene("GameOver");
    }


    void Update()
    {
        playerscore.text = "" + score;
        lives.text = "" + PacLives;
        levelText.text = "" + level;
        if(count == 229)
        {
            count += 1;
            NewLevel();
        }
        if(PacLives == 0)
        {
            GameOver();
        }
    }

    public void startConsued(Ghost consumedGhost)
    {
        GameObject[] o = GameObject.FindGameObjectsWithTag("Ghost");
        foreach(GameObject ghost in o)
        {
            ghost.transform.GetComponent<Ghost>().canMove = false;
        }
        GameObject pacMan = GameObject.Find("PacMan");
        pacMan.transform.GetComponent<PacMan>().canMove = false;
        pacMan.transform.GetComponent<SpriteRenderer>().enabled = false;
        consumedGhost.transform.GetComponent<SpriteRenderer>().enabled = false;

        Vector2 pos = consumedGhost.transform.position;

        Vector2 View = Camera.main.WorldToViewportPoint(pos);
        Debug.Log(View);
        Debug.Log(pos);
        consumedScore.GetComponent<RectTransform>().anchorMin = View;
        consumedScore.GetComponent<RectTransform>().anchorMax = View;

        consumedScore.GetComponent<Text>().enabled = true;

        StartCoroutine(ProcessConsumend(0.75f, consumedGhost));
    }

    IEnumerator ProcessConsumend(float delay, Ghost consumedGhost)
    {
        yield return new WaitForSeconds(delay);
        consumedScore.GetComponent<Text>().enabled = false;
        GameObject pacMan = GameObject.Find("PacMan");
        pacMan.transform.GetComponent<SpriteRenderer>().enabled = true;
        consumedGhost.transform.GetComponent<SpriteRenderer>().enabled = true;
        GameObject[] o = GameObject.FindGameObjectsWithTag("Ghost");
        foreach(GameObject ghost in o)
        {
            ghost.transform.GetComponent<Ghost>().canMove = true;
        }
        pacMan.transform.GetComponent<PacMan>().canMove = true;
    }
}
