﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Tile : MonoBehaviour {

	public bool isPortal;
	public bool isPellet;
	public bool isSuperPellet;
	public bool didConsume;
	public bool isGhostHouseEnterence;
	public bool isGhostHouse;

	public GameObject Preciver;

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
